package com.anjos_bolos.anjos_bolos_api.infrastructure.web;

import com.anjos_bolos.anjos_bolos_api.infrastructure.persistence.jpa.dto.receita.ReceitaCadastroDto;
import com.anjos_bolos.anjos_bolos_api.infrastructure.persistence.jpa.dto.receita.ReceitaListagemDto;
import com.anjos_bolos.anjos_bolos_api.infrastructure.persistence.jpa.dto.receita.ReceitaResponseDto;
import com.anjos_bolos.anjos_bolos_api.infrastructure.persistence.jpa.entity.Receita;
import com.anjos_bolos.anjos_bolos_api.infrastructure.persistence.jpa.mapper.ReceitaMapper;
import com.anjos_bolos.anjos_bolos_api.core.application.usecase.receita.ReceitaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/receitas")
public class ReceitaController {
    private final ReceitaService receitaService;

    public ReceitaController(ReceitaService receitaService) {
        this.receitaService = receitaService;
    }

    @Operation(summary = "Cadastrar nova receita", description = "Cria e salva uma nova receita no banco de dados.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Receita cadastrada com sucesso"),
            @ApiResponse(responseCode = "409", description = "Conflito ao cadastrar receita")
    })
    @PostMapping
    public ResponseEntity<ReceitaResponseDto> cadastrarReceita(
            @RequestBody ReceitaCadastroDto receitaParaCadastrar) {

        System.out.println("Acessando Controller...");

        Receita entity = ReceitaMapper.toEntity(receitaParaCadastrar);

        System.out.println("Convertido para Entidade");

        Receita receitaCadastrada = receitaService.cadastrar(entity);

        System.out.println("Enviando para Service...");

        ReceitaResponseDto dto = ReceitaMapper.toResponse(receitaCadastrada);
        System.out.println("Retornando...");

        return ResponseEntity.status(201).body(dto);
    }

    @Operation(summary = "Listar todas as receitas", description = "Retorna uma lista com todas as receitas cadastradas.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Receitas encontradas"),
            @ApiResponse(responseCode = "204", description = "Nenhuma receita encontrada")
    })
    @GetMapping
    public ResponseEntity<List<ReceitaListagemDto>> listarReceitas() {
        List<Receita> receitas = receitaService.listar();
        if (receitas.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<ReceitaListagemDto> dto = ReceitaMapper.toListagemDtos(receitas);
        return ResponseEntity.status(200).body(dto);
    }

    @Operation(summary = "Calcular custo da receita", description = "Calcula o custo de produção de uma receita e sugere um preço de venda com base no markup.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Custo calculado com sucesso"),
            @ApiResponse(responseCode = "404", description = "Produto/Receita não encontrada")
    })
    @GetMapping("/calcular-preco/{idProduto}")
    public ResponseEntity<String> calcularPreco(
            @Parameter(description = "ID do produto associado à receita") @PathVariable Integer idProduto
    ) {
        Double valorCusto = receitaService.calcularPreco(idProduto);
        Double valorFinal = receitaService.buscarReceitaPorProduto(idProduto).getProduto().getValorFinal();

        return ResponseEntity.status(200).body(
                "O Custo de Produção da Receita de '' é de: R$ %.2f. Preço Sugerido: R$ %.2f. O Preço Atual desse Produto é de R$ %.2f"
                        .formatted(valorCusto, valorCusto * 1.40, valorFinal)
        );
    }

    @Operation(summary = "Excluir receita por produto", description = "Remove todas as receitas associadas a um produto específico.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Receita(s) excluída(s) com sucesso"),
            @ApiResponse(responseCode = "404", description = "Produto ou receita não encontrada")
    })
    @DeleteMapping("produto/{idProduto}")
    public ResponseEntity<Void> excluirReceita(
            @Parameter(description = "ID do produto para exclusão da(s) receita(s)") @PathVariable Integer idProduto
    ) {
        receitaService.excluir(idProduto);
        return ResponseEntity.status(204).build();
    }
}
