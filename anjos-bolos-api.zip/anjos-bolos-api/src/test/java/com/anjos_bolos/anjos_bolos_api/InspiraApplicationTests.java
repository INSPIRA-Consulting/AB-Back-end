package com.anjos_bolos.anjos_bolos_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InspiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
